package com.move2unlock.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
class MainActivity: ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
@Composable fun App(){var reps by remember{mutableIntStateOf(0)};val target=20;MaterialTheme{Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(18.dp)){Text("Move2Unlock",style=MaterialTheme.typography.headlineLarge);Text("Earn your screen time.");Card{Column(Modifier.padding(20.dp)){Text("🔒 Instagram is locked",style=MaterialTheme.typography.titleLarge);Text("Complete 20 squats to earn 30 minutes.");Text("Squats: $reps / $target");Button(onClick={if(reps<target)reps++}){Text(if(reps<target)"Complete Rep" else "Workout Complete ✓")}}};if(reps>=target)Button(onClick={}){Text("Unlock 30 Minutes")};Text("MVP starter — app blocking, camera verification, stats and billing come next.")}}}
